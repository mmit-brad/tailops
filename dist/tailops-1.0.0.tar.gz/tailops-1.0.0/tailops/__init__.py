"""
tailops - Multi-tenant CLI and API toolkit for managing Tailscale tailnets at MSP scale.
"""

__version__ = "1.0.0"
__author__ = "tailops"
__description__ = "Multi-tenant CLI and API toolkit for managing Tailscale tailnets at MSP scale"
